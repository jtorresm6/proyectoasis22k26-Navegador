﻿using System;
using CapaControlador_OrdenesCompra.Entidades;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Valida los datos recibidos para operar sobre órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Reune las reglas de entrada antes de modificar una orden: IDs positivos, código obligatorio de hasta 30
 * caracteres, comentario de hasta 500 caracteres y fechas coherentes. Comprueba el rango y la precision de
 * los importes y del tipo de cambio, y evita descuentos mayores que el subtotal. Normaliza los textos y
 * produce excepciones cuando una entrada no es valida. No abre conexiones ni modifica tablas.
 */


namespace CapaControlador_OrdenesCompra.Servicios
{
    internal static class ClsValidacionOrdenesCompra
    {
        /// <summary>
        /// Comprueba que Id sea positivo; lanza ArgumentOutOfRangeException si no puede representar un PK válido.
        /// </summary>
        internal static void ComprasProcValidarId(int Id)
        {
            if (Id <= 0)
                throw new ArgumentOutOfRangeException(nameof(Id));
        }

        /// <summary>
        /// Comprueba que Valor sea no negativo, no exceda Máximo y respete Decimales; identifica el campo invalido
        /// en la excepción.
        /// </summary>
        private static void ComprasProcValidarDecimal(decimal Valor, decimal Maximo, int Decimales, string Campo)
        {
            if (Valor < 0 || Valor > Maximo || decimal.Round(Valor, Decimales) != Valor)
                throw new ArgumentOutOfRangeException(Campo, "El valor excede el rango o la precisión permitidos.");
        }

        /// <summary>
        /// Recorta espacios en los extremos y devuelve un código de 1 a 30 caracteres; rechaza null, vacío y
        /// longitudes excesivas.
        /// </summary>
        internal static string ComprasFuncNormalizarCodigo(string CodigoOrdenCompra)
        {
            string Codigo = (CodigoOrdenCompra ?? string.Empty).Trim();
            if (Codigo.Length == 0 || Codigo.Length > 30)
                throw new ArgumentException("El codigo de la orden debe tener entre 1 y 30 caracteres.", nameof(CodigoOrdenCompra));
            return Codigo;
        }

        /// <summary>
        /// Convierte null en texto vacío, recorta espacios y devuelve hasta 500 caracteres; rechaza textos mas
        /// largos.
        /// </summary>
        internal static string ComprasFuncNormalizarComentario(string Comentario)
        {
            string Texto = (Comentario ?? string.Empty).Trim();
            if (Texto.Length > 500)
                throw new ArgumentException("El comentario admite hasta 500 caracteres.", nameof(Comentario));
            return Texto;
        }

        /// <summary>
        /// Valida IDs, orden de fechas, tipo de cambio positivo y precision monetaria; impide que el descuento
        /// exceda el subtotal.
        /// </summary>
        internal static void ComprasProcValidarCreacion(int IdProveedor, int IdPlazo, int IdMoneda,
            DateTime Emision, DateTime Vencimiento, decimal TipoCambio, decimal Subtotal, decimal Descuento)
        {
            if (IdProveedor <= 0 || IdPlazo <= 0 || IdMoneda <= 0)
                throw new ArgumentException("Selecciona proveedor, plazo y moneda válidos.");
            if (Emision.Date > Vencimiento.Date)
                throw new ArgumentException("El vencimiento no puede ser anterior a la emisión.");
            ComprasProcValidarDecimal(TipoCambio, 999999.999999M, 6, nameof(TipoCambio));
            if (TipoCambio == 0)
                throw new ArgumentException("El tipo de cambio debe ser positivo.", nameof(TipoCambio));
            ComprasProcValidarDecimal(Subtotal, 99999999.9999M, 4, nameof(Subtotal));
            ComprasProcValidarDecimal(Descuento, Subtotal, 4, nameof(Descuento));
        }

        /// <summary>
        /// Exige una orden existente y pendiente, y una fecha igual o posterior a su emisión; no modifica la orden.
        /// </summary>
        internal static void ComprasProcValidarVencimiento(ClsOrdenCompra Orden, DateTime Fecha)
        {
            if (Orden == null || Orden.Estado != "Pendiente")
                throw new InvalidOperationException("Solo se puede modificar una orden pendiente.");
            if (Fecha.Date < Orden.FechaEmision)
                throw new ArgumentException("El vencimiento no puede ser anterior a la emisión.", nameof(Fecha));
        }
    }
}
