﻿using System;
using System.Data;
using System.Globalization;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Filtra las filas de órdenes de compra por texto, estado y fechas.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Recibe una DataTable ya consultada y genera otra con las filas que cumplen texto, estado y rango de
 * emisión. Busca en código de orden, nombre de proveedor y NIT sin distinguir mayúsculas ni acentos. Valida
 * que las dos fechas se proporcionen juntas, incluye los limites del rango y omite filas eliminadas. No
 * modifica la tabla original ni consulta la base de datos; quien recibe el resultado debe liberarlo.
 */


namespace CapaControlador_OrdenesCompra.Servicios
{
    internal static class ClsFiltroOrdenesCompra
    {
        private static readonly string[] _CamposBusqueda = { "codigoOrdenCompra", "nombreProveedor", "nitProveedor" };

        /// <summary>
        /// Valida tabla, estado y rango; copia las filas coincidentes por texto y fecha a una tabla nueva, omitiendo
        /// filas eliminadas.
        /// </summary>
        internal static DataTable ComprasFuncFiltrar(DataTable Datos, string Palabra, string Estado, DateTime? Inicio, DateTime? Fin)
        {
            if (Datos == null)
                throw new ArgumentNullException(nameof(Datos));
            if (Inicio.HasValue != Fin.HasValue || (Inicio.HasValue && Inicio.Value.Date > Fin.Value.Date))
                throw new ArgumentException("El rango de fechas no es válido.");
            bool FiltrarEstado = !string.IsNullOrEmpty(Estado) && Estado != "Todos";
            if (FiltrarEstado)
                ClsEstadosOrdenesCompra.ComprasProcValidarFiltro(Estado);
            string Buscar = (Palabra ?? string.Empty).Trim();
            DataTable Resultado = Datos.Clone();
            foreach (DataRow Fila in Datos.Rows)
            {
                if (Fila.RowState == DataRowState.Deleted)
                    continue;
                if (FiltrarEstado && !string.Equals(Convert.ToString(Fila["estadoOrdenCompra"]), Estado, StringComparison.OrdinalIgnoreCase))
                    continue;
                DateTime Emision = Convert.ToDateTime(Fila["fechaEmisionOrdenCompra"]).Date;
                if (Inicio.HasValue && (Emision < Inicio.Value.Date || Emision > Fin.Value.Date))
                    continue;
                if (ComprasFuncCoincideBusqueda(Fila, Buscar))
                    Resultado.ImportRow(Fila);
            }
            return Resultado;
        }

        /// <summary>
        /// Devuelve true si Buscar esta vacío o aparece en código, proveedor o NIT sin distinguir mayúsculas ni
        /// acentos.
        /// </summary>
        private static bool ComprasFuncCoincideBusqueda(DataRow Fila, string Buscar)
        {
            if (Buscar.Length == 0)
                return true;
            foreach (string Campo in _CamposBusqueda)
            {
                if (CultureInfo.CurrentCulture.CompareInfo.IndexOf(Convert.ToString(Fila[Campo]), Buscar,
                    CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace) >= 0)
                    return true;
            }
            return false;
        }
    }
}
