﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using CapaModelo_OrdenesCompra.Entidades;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Consulta los datos de órdenes de compra y sus catálogos.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Contiene las lecturas SQL del módulo: encabezados, encabezados filtrados por estado, una orden por PK,
 * sus detalles y los proveedores activos. El encabezado incorpora proveedor y plazo mediante uniones, y las
 * listas se ordenan de la emisión mas reciente a la mas antigua. Pasa los valores variables como parámetros
 * ODBC. No modifica registros y devuelve null cuando no encuentra una orden por ID.
 */


namespace CapaModelo_OrdenesCompra.Repositorios
{
    internal sealed class ClsConsultasOrdenesCompra : ClsRepositorioBaseOrdenesCompra
    {
        private const string _Consulta = "SELECT o.idOrdenCompra, o.codigoOrdenCompra, o.idProveedor, o.idPlazo, o.idMoneda, "
            + "o.fechaEmisionOrdenCompra, o.fechaVencimientoOrdenCompra, o.tipoCambioOrdenCompra, "
            + "o.subtotalOrdenCompra, o.descuentoOrdenCompra, o.totalOrdenCompra, "
            + "o.comentarioOrdenCompra, o.estadoOrdenCompra, p.nombreProveedor, p.nitProveedor, "
            + "p.telefonoProveedor, p.correoProveedor, p.direccionProveedor, p.estadoProveedor, "
            + "z.nombrePlazo, z.diasPlazo FROM tblOrdenCompra o "
            + "INNER JOIN tblProveedor p ON p.idProveedor = o.idProveedor "
            + "INNER JOIN tblPlazo z ON z.idPlazo = o.idPlazo ";

        /// <summary>
        /// Consulta todos los encabezados con proveedor y plazo, ordenados por emisión e ID descendentes.
        /// </summary>
        internal DataTable ComprasFuncListar()
        {
            return ComprasFuncConsultar(_Consulta + "ORDER BY o.fechaEmisionOrdenCompra DESC, o.idOrdenCompra DESC");
        }

        /// <summary>
        /// Filtra los encabezados por un estado parametrizado y conserva el orden por emisión e ID descendentes.
        /// </summary>
        internal DataTable ComprasFuncListar(string Estado)
        {
            return ComprasFuncEjecucionConsulta(_Consulta + "WHERE o.estadoOrdenCompra = ? "
                + "ORDER BY o.fechaEmisionOrdenCompra DESC, o.idOrdenCompra DESC", CommandType.Text,
                new List<OdbcParameter> { new OdbcParameter("Estado", OdbcType.VarChar, 30) { Value = Estado } });
        }

        /// <summary>
        /// Valida el PK, consulta su encabezado y materializa una entidad; libera la tabla auxiliar y devuelve null
        /// si no hay fila.
        /// </summary>
        internal ClsOrdenCompra ComprasFuncObtener(int Id)
        {
            ComprasProcValidarId(Id);
            using (DataTable Datos = ComprasFuncConsultar(_Consulta + "WHERE o.idOrdenCompra = ?", Id))
            {
                return Datos.Rows.Count == 0 ? null : new ClsOrdenCompra(Datos.Rows[0]);
            }
        }

        /// <summary>
        /// Valida el PK y consulta productos, cantidades, costos, descuentos y subtotales de la orden, ordenados por
        /// producto.
        /// </summary>
        internal DataTable ComprasFuncListarDetalles(int Id)
        {
            ComprasProcValidarId(Id);
            return ComprasFuncConsultar("SELECT idProducto, cantidadDetalleOrdenCompra, "
                + "costoUnitarioDetalleOrdenCompra, descuentoPorcentajeDetalleOrdenCompra, "
                + "subtotalDetalleOrdenCompra FROM tblDetalleOrdenCompra WHERE idOrdenCompra = ? ORDER BY idProducto", Id);
        }

        /// <summary>
        /// Consulta solo proveedores activos con las columnas necesarias para mostrar sus datos, ordenados por
        /// nombre.
        /// </summary>
        internal DataTable ComprasFuncListarProveedores()
        {
            return ComprasFuncConsultar("SELECT idProveedor, nombreProveedor, nitProveedor, telefonoProveedor, "
                + "correoProveedor, direccionProveedor, estadoProveedor FROM tblProveedor "
                + "WHERE estadoProveedor = 1 ORDER BY nombreProveedor");
        }

        /// <summary>
        /// Agrega el parámetro entero Id cuando se proporciona y ejecuta la consulta de texto mediante la
        /// infraestructura ODBC.
        /// </summary>
        private DataTable ComprasFuncConsultar(string Sql, int? Id = null)
        {
            var Parametros = new List<OdbcParameter>();
            if (Id.HasValue)
                Parametros.Add(new OdbcParameter("Id", OdbcType.Int) { Value = Id.Value });
            return ComprasFuncEjecucionConsulta(Sql, CommandType.Text, Parametros);
        }

        /// <summary>
        /// Comprueba que Id sea positivo; lanza ArgumentOutOfRangeException si no puede representar un PK válido.
        /// </summary>
        private static void ComprasProcValidarId(int Id)
        {
            if (Id <= 0)
                throw new ArgumentOutOfRangeException(nameof(Id));
        }
    }
}
