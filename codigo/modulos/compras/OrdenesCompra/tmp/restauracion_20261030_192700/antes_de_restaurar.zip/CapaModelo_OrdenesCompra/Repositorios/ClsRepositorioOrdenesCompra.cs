﻿using System;
using System.Data;
using CapaModelo_OrdenesCompra.Contratos;
using CapaModelo_OrdenesCompra.Entidades;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Implementa el contrato de persistencia de órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Es la implementacion pública del contrato de persistencia. Mantiene una clase de consultas y otra de
 * comandos, y entrega cada llamada a la que corresponde. Evita que el controlador conozca las clases
 * internas que contienen SQL. No repite las reglas de entrada del controlador ni abre conexiones
 * directamente.
 */


namespace CapaModelo_OrdenesCompra.Repositorios
{
    public sealed class ClsRepositorioOrdenesCompra : IRepositorioOrdenesCompra
    {
        private readonly ClsConsultasOrdenesCompra _Consultas = new ClsConsultasOrdenesCompra();
        private readonly ClsComandosOrdenesCompra _Comandos = new ClsComandosOrdenesCompra();

        /// <summary>
        /// Entrega a la clase de consultas la lectura de todas las órdenes y devuelve su tabla.
        /// </summary>
        public DataTable ComprasFuncListar() => _Consultas.ComprasFuncListar();
        /// <summary>
        /// Entrega el estado a la clase de consultas para filtrar en la base de datos; espera un estado ya validado.
        /// </summary>
        public DataTable ComprasFuncListar(string Estado) => _Consultas.ComprasFuncListar(Estado);
        /// <summary>
        /// Delega en consultas la recuperacion de una orden por PK; conserva null cuando no se encuentra.
        /// </summary>
        public ClsOrdenCompra ComprasFuncObtener(int Id) => _Consultas.ComprasFuncObtener(Id);
        /// <summary>
        /// Delega en consultas la recuperacion de los productos vinculados al PK de la orden.
        /// </summary>
        public DataTable ComprasFuncListarDetalles(int Id) => _Consultas.ComprasFuncListarDetalles(Id);
        /// <summary>
        /// Delega en consultas la lectura de proveedores activos.
        /// </summary>
        public DataTable ComprasFuncListarProveedores() => _Consultas.ComprasFuncListarProveedores();
        /// <summary>
        /// Entrega a comandos la anulación de la orden indicada; propaga los errores de la operación.
        /// </summary>
        public void ComprasProcAnular(int Id) => _Comandos.ComprasProcAnular(Id);
        /// <summary>
        /// Entrega a comandos el PK y el estado solicitado; no ejecuta SQL en esta fachada.
        /// </summary>
        public void ComprasProcCambiarEstado(int Id, string Estado) => _Comandos.ComprasProcCambiarEstado(Id, Estado);
        /// <summary>
        /// Entrega a comandos la actualización del vencimiento de la orden indicada.
        /// </summary>
        public void ComprasProcActualizarVencimiento(int Id, DateTime Fecha) => _Comandos.ComprasProcActualizarVencimiento(Id, Fecha);

        /// <summary>
        /// Entrega los datos del encabezado a comandos y devuelve el PK que esa clase genere.
        /// </summary>
        public int ComprasFuncCrear(string CodigoOrdenCompra, int IdProveedor, int IdPlazo, int IdMoneda, DateTime Emision,
            DateTime Vencimiento, decimal TipoCambio, decimal Subtotal, decimal Descuento, string Comentario)
        {
            return _Comandos.ComprasFuncCrear(CodigoOrdenCompra, IdProveedor, IdPlazo, IdMoneda,
                Emision, Vencimiento, TipoCambio, Subtotal, Descuento, Comentario);
        }
    }
}
