﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using CapaModelo_Seguridad;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Ejecuta operaciones ODBC con la conexión de la DLL de Seguridad.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Proporciona la infraestructura ODBC compartida por consultas y comandos. Obtiene una conexión desde la
 * DLL de Seguridad, la abre, ejecuta la operación recibida y la libera. Cuando se solicita una transaccion,
 * confirma solo si la operación termina correctamente; al fallar se libera sin confirmar. Construye
 * comandos con parámetros y un tiempo limite de 20 segundos, y delega la traduccion de los errores ODBC a
 * una clase especializada.
 */

namespace CapaModelo_OrdenesCompra.Repositorios
{
    public abstract class ClsRepositorioBaseOrdenesCompra : ClsConexion
    {
        /// <summary>
        /// Ejecuta un lector ODBC y carga sus filas en una DataTable; libera comando, lector y conexión, pero
        /// entrega la tabla al consumidor.
        /// </summary>
        protected DataTable ComprasFuncEjecucionConsulta(string ComandoTexto, CommandType ComandoTipo,
            List<OdbcParameter> Parametros = null)
        {
            return ComprasFuncEjecutar((Conexion, Transaccion) =>
            {
                using (var Comando = ComprasFuncCrearComando(Conexion, Transaccion, ComandoTexto, ComandoTipo, Parametros))
                using (var Lector = Comando.ExecuteReader())
                {
                    var Datos = new DataTable();
                    Datos.Load(Lector);
                    return Datos;
                }
            }, false);
        }

        /// <summary>
        /// Ejecuta un comando de escritura parametrizado sin transaccion explicita y devuelve el número de filas
        /// afectadas.
        /// </summary>
        protected int ComprasFuncEjecucionNonQuery(string ComandoTexto, List<OdbcParameter> Parametros,
            CommandType ComandoTipo)
        {
            return ComprasFuncEjecutar((Conexion, Transaccion) =>
            {
                using (var Comando = ComprasFuncCrearComando(Conexion, Transaccion, ComandoTexto, ComandoTipo, Parametros))
                    return Comando.ExecuteNonQuery();
            }, false);
        }

        /// <summary>
        /// Abre una conexión de Seguridad, ejecuta la función recibida y devuelve su resultado. Si se solicita
        /// transaccion, confirma al terminar; libera recursos al fallar y traduce excepciones ODBC conservando la
        /// causa original.
        /// </summary>
        protected Resultado ComprasFuncEjecutar<Resultado>(Func<OdbcConnection, OdbcTransaction, Resultado> Operacion,
            bool UsarTransaccion)
        {
            if (Operacion == null) throw new ArgumentNullException(nameof(Operacion));
            try
            {
                using (var Conexion = SeguridadMetObtenerConexion())
                {
                    Conexion.Open();
                    if (!UsarTransaccion) return Operacion(Conexion, null);
                    using (var Transaccion = Conexion.BeginTransaction())
                    {
                        Resultado Valor = Operacion(Conexion, Transaccion);
                        Transaccion.Commit();
                        return Valor;
                    }
                }
            }
            catch (OdbcException Error)
            {
                throw ClsErroresDatosOrdenesCompra.ComprasFuncTraducirError(Error);
            }
        }


        /// <summary>
        /// Crea un OdbcCommand con conexión, transaccion, tipo, parámetros y tiempo limite de 20 segundos; el
        /// llamador debe liberarlo.
        /// </summary>
        protected static OdbcCommand ComprasFuncCrearComando(OdbcConnection Conexion, OdbcTransaction Transaccion,
            string ComandoTexto, CommandType ComandoTipo, List<OdbcParameter> Parametros)
        {
            var Comando = new OdbcCommand(ComandoTexto, Conexion, Transaccion)
            {
                CommandType = ComandoTipo,
                CommandTimeout = 20
            };
            if (Parametros != null) Comando.Parameters.AddRange(Parametros.ToArray());
            return Comando;
        }
    }
}
