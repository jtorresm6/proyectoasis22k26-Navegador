﻿using System;
using System.Drawing;
using System.Windows.Forms;
using CapaVista_Componentes.Componentes;

/*
 * ==================================================================
 * Área : Compras
 * Autor : Diego Fernando Santizo Samayoa
 * Carné : 0901-22-15950
 * Fecha : 24/10/2026
 * ==================================================================
 * Propósito :
 *  Configura las columnas de los DGV de órdenes de compra.
 * ===================================================================
*/

/*
 * EXPLICACION TEMPORAL DE LA CLASE
 * Define las columnas visibles y sus vínculos a las columnas de las tablas de datos para ambos DGV.
 * Configura titulos, pesos y formatos de fechas, cantidades, porcentajes e importes sin agregar una columna
 * de cambio de estado. Mantiene las tablas de solo lectura y evita altas o eliminaciones desde la rejilla.
 * No consulta datos ni ejecuta operaciones de negocio.
 */

namespace CapaVista_OrdenesCompra.Presentacion
{
    internal static class ClsTablasOrdenesCompra
    {
        /// <summary>
        /// Crea las columnas enlazadas de código, proveedor, fechas, importes, moneda y estado; aplica formatos y
        /// deja el listado sin altas, bajas ni edicion.
        /// </summary>
        internal static void ComprasProcConfigurarEncabezados(ComprasUsrDataGridView Tabla)
        {
            Tabla.Tabla.RowTemplate.MinimumHeight = 40;
            Tabla.Tabla.RowTemplate.Height = 40;
            Tabla.AutoGenerateColumns = false;
            foreach (var Campo in new[] {
                new[] { "codigoOrdenCompra", "Código", "16" },
                new[] { "nombreProveedor", "Proveedor", "24" },
                new[] { "nitProveedor", "NIT", "11" },
                new[] { "fechaEmisionOrdenCompra", "Emisión", "12" },
                new[] { "fechaVencimientoOrdenCompra", "Vencimiento", "12" },
                new[] { "totalOrdenCompra", "Monto total", "12" },
                new[] { "idMoneda", "Moneda (ID)", "12" },
                new[] { "estadoOrdenCompra", "Estado", "11" } })
            {
                var Columna = new DataGridViewTextBoxColumn { Name = "ComprasCol" + Campo[0],
                    DataPropertyName = Campo[0], HeaderText = Campo[1], FillWeight = int.Parse(Campo[2]), ReadOnly = true };
                if (Campo[0].StartsWith("fecha")) Columna.DefaultCellStyle.Format = "dd/MM/yyyy";
                if (Campo[0] == "totalOrdenCompra")
                {
                    Columna.DefaultCellStyle.Format = "#,##0.0000";
                    Columna.DefaultCellStyle.FormatProvider = System.Globalization.CultureInfo.InvariantCulture;
                    Columna.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                Tabla.Columns.Add(Columna);
            }
            Tabla.ReadOnly = true;
            Tabla.AllowUserToAddRows = false;
            Tabla.AllowUserToDeleteRows = false;
        }

        /// <summary>
        /// Crea las columnas de producto, cantidad, costo, descuento y subtotal, configura su precision y alineacion
        /// y deja el detalle de solo lectura.
        /// </summary>
        internal static void ComprasProcConfigurarDetalles(ComprasUsrDataGridView Tabla)
        {
            Tabla.AutoGenerateColumns = false;
            ClsPresentacionCompras.ComprasProcAgregarColumna(Tabla, "idProducto", "ID producto", 12, false);
            ClsPresentacionCompras.ComprasProcAgregarColumna(Tabla, "cantidadDetalleOrdenCompra", "Cantidad", 20, true);
            ClsPresentacionCompras.ComprasProcAgregarColumna(Tabla, "costoUnitarioDetalleOrdenCompra", "Costo unitario", 22, true);
            ClsPresentacionCompras.ComprasProcAgregarColumna(Tabla, "descuentoPorcentajeDetalleOrdenCompra", "Descuento %", 20, true);
            ClsPresentacionCompras.ComprasProcAgregarColumna(Tabla, "subtotalDetalleOrdenCompra", "Subtotal", 22, true);
            foreach (DataGridViewColumn Columna in Tabla.Columns)
                Columna.DefaultCellStyle.Format = Columna.DataPropertyName == "idProducto" ? "0" : "N4";
            Tabla.Columns["ComprasColdescuentoPorcentajeDetalleOrdenCompra"].DefaultCellStyle.Format = "N2";
            Tabla.Tabla.DefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            Tabla.Tabla.ColumnHeadersDefaultCellStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            foreach (System.Windows.Forms.DataGridViewColumn Columna in Tabla.Columns)
            {
                Columna.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            }
            Tabla.ReadOnly = true;
            Tabla.AllowUserToAddRows = false;
            Tabla.AllowUserToDeleteRows = false;

            Tabla.ClearSelection();
        }
    }
}
